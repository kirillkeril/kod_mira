
import {LoginCard} from "../components/LoginCard/LoginCard";

export const LoginPage = () => {
    return (
        <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%'}}>
            <LoginCard/>
        </div>
    );
}