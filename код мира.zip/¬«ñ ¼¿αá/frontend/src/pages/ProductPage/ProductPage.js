import {ProductForm} from "../../components/ProductForm/ProductForm";

export const ProductPage = () => {
    return (
    <>
        <ProductForm/>
    </>
    );
}